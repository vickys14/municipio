@echo off
cd /d "%~dp0"

echo =========================================
echo   Iniciando proyecto Municipios (Docker)
echo =========================================
echo.

where docker.exe >nul 2>nul
if errorlevel 1 (
    echo ERROR: Docker no esta instalado o no esta en el PATH.
    echo Descargalo de: https://www.docker.com/products/docker-desktop/
    echo.
    pause
    exit /b 1
)

echo Verificando si Docker Desktop esta corriendo...
docker.exe info >nul 2>nul
if errorlevel 1 (
    echo Docker Desktop no esta corriendo. Abrelo manualmente y espera a que
    echo el icono de la ballena en la barra de tareas quede quieto.
    echo Luego vuelve a ejecutar este archivo.
    echo.
    pause
    exit /b 1
)

echo Docker esta listo. Levantando el contenedor...
echo.
docker.exe compose up -d

echo.
echo =========================================
echo   Contenedor listo.
echo   Host: 127.0.0.1
echo   Puerto: 3010
echo   Usuario: appuser
echo   Password: app_pass
echo   Base de datos: Municipio
echo =========================================
echo.

REM ---------------------------------------------
REM  Entorno de Python para Jupyter (.venv)
REM  Solo se crea la PRIMERA vez en este computador.
REM ---------------------------------------------

if exist ".venv\pyvenv.cfg" (
    echo El entorno .venv ya existe en este computador, no se vuelve a crear.
) else (
    echo No se encontro un .venv en este computador. Creandolo por primera vez...
    echo Esto puede tardar 1-2 minutos, solo pasa una vez por PC.
    echo.

    where python >nul 2>nul
    if errorlevel 1 (
        echo ERROR: Python no esta instalado o no esta en el PATH.
        echo Descargalo de: https://www.python.org/downloads/
        echo.
        pause
        goto abrir_vscode
    )

    python -m venv .venv

    call .venv\Scripts\activate.bat
    pip install -r requirements.txt
    python -m ipykernel install --user --name=municipios-venv --display-name "Python (municipios-venv)"

    echo.
    echo Entorno .venv creado y kernel de Jupyter registrado.
)

:abrir_vscode
echo.

where code >nul 2>nul
if errorlevel 1 (
    echo VS Code no se detecto en el PATH. Abrelo manualmente.
) else (
    echo Abriendo VS Code...
    code .
)

echo.
echo Listo. Si es la primera vez, recuerda seleccionar el kernel
echo "Python (municipios-venv)" dentro de consultas.ipynb.
echo.
pause
