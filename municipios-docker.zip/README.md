# Proyecto Municipios - MariaDB en Docker + VS Code

## Nota sobre el error "unknown plugin auth_gssapi_client"

Si ya habías levantado el proyecto antes con la version 11.x de MariaDB, es indispensable borrar el volumen viejo, porque el cambio de imagen y el fix de autenticacion solo se aplican en una base de datos nueva:

```bash
docker compose down -v
docker compose up -d
```

Sin el `-v` el volumen viejo persiste con la configuracion vieja y el error se repite.

## Jupyter con entorno virtual (.venv)

Ademas de SQLTools, este proyecto incluye un notebook (`consultas.ipynb`) para consultar la base desde Python/Jupyter.

```powershell
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python -m ipykernel install --user --name=municipios-venv --display-name "Python (municipios-venv)"
```

Luego abre `consultas.ipynb` en VS Code, selecciona el kernel **Python (municipios-venv)** y ejecuta las celdas.

El notebook usa el usuario `appuser` / `app_pass` (el mismo que en SQLTools) para conectarse al contenedor en el puerto `3010`.

## Estructura

```
municipios-docker/
├── docker-compose.yml
├── consulta.sql              <- tu consulta original, para usarla en VS Code
├── README.md
└── init/
    ├── 01-base.sql            <- crea la base y las tablas
    ├── 02-cargar.sql          <- carga los datos del CSV
    └── municipios.csv         <- tus datos
```

## Requisitos previos (solo se instalan UNA VEZ)

1. Tener **Docker Desktop** instalado (https://www.docker.com/products/docker-desktop/).
2. Tener **VS Code** instalado, con las extensiones:
   - `SQLTools` (Matheus Teixeira)
   - `SQLTools MySQL/MariaDB/TiDB Driver` (Matheus Teixeira)

## Opción rápida: doble clic en `iniciar_proyecto.bat`

Ya con Docker Desktop y VS Code instalados, todo lo demás es automático:

**Doble clic en `iniciar_proyecto.bat`**

Ese archivo:
1. Verifica que Docker esté instalado.
2. Si Docker Desktop no está abierto, lo abre y espera a que arranque.
3. Levanta el contenedor con la base de datos ya cargada (`docker compose up -d`).
4. Abre VS Code en esta misma carpeta.

Solo falta conectar SQLTools la primera vez (Paso 2, más abajo) — eso no se puede automatizar porque VS Code no lo permite por seguridad.

---

## Opción manual (paso a paso, por si el .bat falla)

### Paso 1: Levantar el contenedor

Abre una terminal DENTRO de la carpeta `municipios-docker` (donde está el `docker-compose.yml`) y ejecuta:

```bash
docker compose up -d
```

Esto va a:
- Descargar la imagen de MariaDB (solo la primera vez).
- Crear el contenedor `municipios_db`.
- Automáticamente crear la base `Municipio`, las tablas, y cargar los datos del CSV (solo la primera vez que se crea el volumen).

Puedes ver los logs para confirmar que la carga fue exitosa:

```bash
docker compose logs -f mariadb
```

(Ctrl+C para salir de los logs, el contenedor sigue corriendo en segundo plano)

## Paso 2: Conectar VS Code (SQLTools)

1. Abre VS Code en la carpeta `municipios-docker`.
2. Clic en el ícono de SQLTools en la barra lateral.
3. **Add New Connection** → selecciona **MySQL/MariaDB**.
4. Llena los datos:

   | Campo | Valor |
   |---|---|
   | Connection name | Municipios Docker |
   | Server / Host | `127.0.0.1` |
   | Port | `3010` |
   | Database | `Municipio` |
   | Username | `root` |
   | Password | `root123` |

5. **Test Connection** → si sale bien, **Save Connection**.

Ahora en el panel de SQLTools verás:

```
Municipios Docker
  └── Municipio
        └── Tables
              ├── Region
              ├── Departamento
              └── Municipio
```

## Paso 3: Hacer consultas

Abre `consulta.sql` en VS Code (ya está incluido en este proyecto), o crea uno nuevo, escribe tu SQL y ejecútalo con:

- Click derecho → **Run on Active Connection**, o
- Atajo `Ctrl+E Ctrl+E`

## Comandos útiles de Docker

| Acción | Comando |
|---|---|
| Levantar el contenedor | `docker compose up -d` |
| Ver logs | `docker compose logs -f mariadb` |
| Detener el contenedor | `docker compose down` |
| Detener y BORRAR todos los datos (para recargar desde cero) | `docker compose down -v` |
| Ver si está corriendo | `docker ps` |

## Importante: portabilidad a cualquier PC

Esto es justo lo que buscabas: en **cualquier computador** que tenga Docker instalado, solo necesitas:

1. Copiar la carpeta completa `municipios-docker/`.
2. Ejecutar `docker compose up -d` parado en esa carpeta.
3. Conectar VS Code con los mismos datos de la tabla de arriba (siempre son `127.0.0.1`, puerto `3306`, usuario `root`, password `root123` — no cambian porque están definidos en el propio `docker-compose.yml`).

No hay ninguna ruta de Windows (`C:/Users/...`) involucrada en ningún paso — todo vive dentro del contenedor.

## Si necesitas recargar los datos desde cero

Como MariaDB solo ejecuta los scripts de `init/` la PRIMERA vez que crea el volumen de datos, si edita el CSV o los scripts y quiere que se vuelva a cargar todo:

```bash
docker compose down -v
docker compose up -d
```

El flag `-v` borra el volumen de datos, forzando que la próxima vez se ejecute `01-base.sql` y `02-cargar.sql` de nuevo.
