SELECT 
    M.NombreMunicipio,
    D.NombreDepartamento
FROM Municipio AS M
INNER JOIN Departamento AS D
    ON M.IdDepartamento = D.IdDepartamento
WHERE M.NombreMunicipio IN (
    SELECT NombreMunicipio
    FROM Municipio
    GROUP BY NombreMunicipio
    HAVING COUNT(*) > 1
)
ORDER BY M.NombreMunicipio, D.NombreDepartamento;