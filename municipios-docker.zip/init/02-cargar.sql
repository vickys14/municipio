USE `Municipio`;

-- CARGAR REGIONES
LOAD DATA INFILE '/docker-entrypoint-initdb.d/municipios.csv'
IGNORE INTO TABLE Region
FIELDS TERMINATED BY ','
LINES TERMINATED BY '\r'
(@region, @codigo_departamento, @nombre_departamento, @codigo_municipio, @nombre_municipio)
SET NombreRegion = TRIM(@region);

-- CARGAR DEPARTAMENTOS
LOAD DATA INFILE '/docker-entrypoint-initdb.d/municipios.csv'
IGNORE INTO TABLE Departamento
FIELDS TERMINATED BY ','
LINES TERMINATED BY '\r'
(@region, @codigo_departamento, @nombre_departamento, @codigo_municipio, @nombre_municipio)
SET
    DaneDepartamento = @codigo_departamento,
    NombreDepartamento = TRIM(@nombre_departamento),
    IdRegion = (SELECT IdRegion FROM Region WHERE NombreRegion = TRIM(@region) LIMIT 1);

-- CARGAR MUNICIPIOS
LOAD DATA INFILE '/docker-entrypoint-initdb.d/municipios.csv'
IGNORE INTO TABLE Municipio
FIELDS TERMINATED BY ','
LINES TERMINATED BY '\r'
(@region, @codigo_departamento, @nombre_departamento, @codigo_municipio, @nombre_municipio)
SET
    DaneMunicipio = @codigo_municipio,
    NombreMunicipio = TRIM(@nombre_municipio),
    IdDepartamento = (SELECT IdDepartamento FROM Departamento WHERE DaneDepartamento = @codigo_departamento LIMIT 1);
