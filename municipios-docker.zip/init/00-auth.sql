-- Fuerza el metodo de autenticacion clasico para evitar
-- el error "unknown plugin" con clientes basados en Node.js (SQLTools, DBeaver, etc.)
ALTER USER 'root'@'%' IDENTIFIED VIA mysql_native_password USING PASSWORD('root123');

-- Usuario de aplicacion (el que usas en SQLTools y en Jupyter)
CREATE USER IF NOT EXISTS 'appuser'@'%' IDENTIFIED VIA mysql_native_password USING PASSWORD('app_pass');
GRANT ALL PRIVILEGES ON Municipio.* TO 'appuser'@'%';

FLUSH PRIVILEGES;
