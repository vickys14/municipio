-- -----------------------------------------------------
-- Base de datos Municipio
-- -----------------------------------------------------

DROP SCHEMA IF EXISTS `Municipio`;

CREATE SCHEMA `Municipio`
DEFAULT CHARACTER SET utf8mb4;

USE `Municipio`;


-- -----------------------------------------------------
-- Tabla Region
-- -----------------------------------------------------

CREATE TABLE `Region` (
    `IdRegion` INT NOT NULL AUTO_INCREMENT,
    `NombreRegion` VARCHAR(100) NOT NULL,

    PRIMARY KEY (`IdRegion`),

    UNIQUE KEY `uk_nombre_region` (`NombreRegion`)
) ENGINE = InnoDB;


-- -----------------------------------------------------
-- Tabla Departamento
-- -----------------------------------------------------

CREATE TABLE `Departamento` (
    `IdDepartamento` INT NOT NULL AUTO_INCREMENT,
    `DaneDepartamento` INT NOT NULL,
    `NombreDepartamento` VARCHAR(100) NOT NULL,
    `IdRegion` INT NOT NULL,

    PRIMARY KEY (`IdDepartamento`),

    UNIQUE KEY `uk_dane_departamento` (`DaneDepartamento`),

    CONSTRAINT `fk_Departamento_Region`
        FOREIGN KEY (`IdRegion`)
        REFERENCES `Region` (`IdRegion`)
        ON DELETE NO ACTION
        ON UPDATE NO ACTION
) ENGINE = InnoDB;


-- -----------------------------------------------------
-- Tabla Municipio
-- -----------------------------------------------------

CREATE TABLE `Municipio` (
    `IdMunicipio` INT NOT NULL AUTO_INCREMENT,
    `DaneMunicipio` VARCHAR(45) NOT NULL,
    `NombreMunicipio` VARCHAR(45) NOT NULL,
    `IdDepartamento` INT NOT NULL,

    PRIMARY KEY (`IdMunicipio`),

    UNIQUE KEY `uk_dane_municipio` (`DaneMunicipio`),

    CONSTRAINT `fk_Municipio_Departamento`
        FOREIGN KEY (`IdDepartamento`)
        REFERENCES `Departamento` (`IdDepartamento`)
        ON DELETE NO ACTION
        ON UPDATE NO ACTION
) ENGINE = InnoDB;
